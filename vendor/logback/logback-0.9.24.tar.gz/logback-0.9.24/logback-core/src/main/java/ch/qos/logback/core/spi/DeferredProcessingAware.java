package ch.qos.logback.core.spi;

public interface DeferredProcessingAware {

  public void prepareForDeferredProcessing();
}
